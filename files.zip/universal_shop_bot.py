import logging
import asyncio
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes, ConversationHandler

logging.basicConfig(level=logging.INFO)

import os
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8981918327:AAEO6FScm8KbfzOjb9Y7gAFmwY2W-63d6Jw")
GROUP_CHAT_ID = -1003932559998
OWNER_ID = int(os.environ.get("OWNER_ID", "1070104264"))

# Mahsulotlar
PRODUCTS = {
    "shampun": [
        {"id": "s1", "name": "Carbon Kiwi Shampun", "price": 45000, "unit": "dona"},
        {"id": "s2", "name": "Argan Oil Shampun", "price": 38000, "unit": "dona"},
        {"id": "s3", "name": "Keratinli Shampun", "price": 52000, "unit": "dona"},
    ],
    "sovun": [
        {"id": "sv1", "name": "Gliserin Sovun", "price": 8500, "unit": "dona"},
        {"id": "sv2", "name": "Antibakterial Sovun", "price": 12000, "unit": "dona"},
        {"id": "sv3", "name": "Lavanda Sovun", "price": 9000, "unit": "dona"},
    ],
    "detergent": [
        {"id": "d1", "name": "Limon Detergent", "price": 18000, "unit": "dona"},
        {"id": "d2", "name": "Kir Yuvish Kukuni", "price": 65000, "unit": "xalta"},
        {"id": "d3", "name": "Oshxona Tozalovchi", "price": 22000, "unit": "dona"},
    ],
    "konditsioner": [
        {"id": "k1", "name": "Soch Konditsioneri", "price": 32000, "unit": "dona"},
    ],
    "yuz": [
        {"id": "y1", "name": "Yuz Tozalovchi Gel", "price": 28000, "unit": "dona"},
        {"id": "y2", "name": "Micellar Suv", "price": 35000, "unit": "dona"},
    ],
}

CATEGORY_NAMES = {
    "shampun": "🧴 Shampun / Шампунь",
    "sovun": "🧼 Sovun / Мыло",
    "detergent": "🫧 Detergent / Моющее",
    "konditsioner": "💆 Konditsioner / Кондиционер",
    "yuz": "✨ Yuz parvarishi / Уход за лицом",
}

# Conversation states
CHOOSING_LANG, CHOOSING_CATEGORY, CHOOSING_PRODUCT, ENTERING_QTY, ENTERING_NAME, ENTERING_PHONE, CONFIRMING = range(7)

def get_all_product(pid):
    for cat, prods in PRODUCTS.items():
        for p in prods:
            if p["id"] == pid:
                return p
    return None

# ───────────────────────────────
async def start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data.clear()
    ctx.user_data["cart"] = []

    keyboard = [
        [InlineKeyboardButton("🇺🇿 O'zbek", callback_data="lang_uz")],
        [InlineKeyboardButton("🇷🇺 Русский", callback_data="lang_ru")],
    ]
    await update.message.reply_text(
        "🛒 *Universal Shop*\n\nTilni tanlang / Выберите язык:",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return CHOOSING_LANG

async def choose_lang(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    lang = query.data.replace("lang_", "")
    ctx.user_data["lang"] = lang
    return await show_categories(query, ctx)

async def show_categories(query, ctx):
    lang = ctx.user_data.get("lang", "uz")
    cart = ctx.user_data.get("cart", [])
    cart_count = sum(i["qty"] for i in cart)

    if lang == "uz":
        text = "📦 *Kategoriyani tanlang:*"
        cart_txt = f"\n\n🛒 Savatda: {cart_count} ta mahsulot" if cart_count > 0 else ""
    else:
        text = "📦 *Выберите категорию:*"
        cart_txt = f"\n\n🛒 В корзине: {cart_count} товар(ов)" if cart_count > 0 else ""

    keyboard = []
    for key, name in CATEGORY_NAMES.items():
        keyboard.append([InlineKeyboardButton(name, callback_data=f"cat_{key}")])

    if cart_count > 0:
        if lang == "uz":
            keyboard.append([InlineKeyboardButton("✅ Zakaz berish", callback_data="checkout")])
        else:
            keyboard.append([InlineKeyboardButton("✅ Оформить заказ", callback_data="checkout")])

    await query.edit_message_text(
        text + cart_txt,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )
    return CHOOSING_CATEGORY

async def choose_category(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "checkout":
        return await ask_name(query, ctx)

    cat = query.data.replace("cat_", "")
    ctx.user_data["current_cat"] = cat
    lang = ctx.user_data.get("lang", "uz")
    products = PRODUCTS[cat]

    keyboard = []
    for p in products:
        price_txt = f"{p['price']:,} so'm".replace(",", " ")
        keyboard.append([InlineKeyboardButton(f"{p['name']} — {price_txt}", callback_data=f"prod_{p['id']}")])

    if lang == "uz":
        keyboard.append([InlineKeyboardButton("⬅️ Orqaga", callback_data="back_cat")])
        text = f"🛍️ *{CATEGORY_NAMES[cat]}*\n\nMahsulotni tanlang:"
    else:
        keyboard.append([InlineKeyboardButton("⬅️ Назад", callback_data="back_cat")])
        text = f"🛍️ *{CATEGORY_NAMES[cat]}*\n\nВыберите товар:"

    await query.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    return CHOOSING_PRODUCT

async def choose_product(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "back_cat":
        return await show_categories(query, ctx)

    pid = query.data.replace("prod_", "")
    product = get_all_product(pid)
    ctx.user_data["current_product"] = product
    lang = ctx.user_data.get("lang", "uz")

    price_txt = f"{product['price']:,} so'm".replace(",", " ")

    if lang == "uz":
        text = f"🏷️ *{product['name']}*\n💰 Narx: {price_txt} / {product['unit']}\n\nNechta kerak? (raqam yozing)"
    else:
        text = f"🏷️ *{product['name']}*\n💰 Цена: {price_txt} / {product['unit']}\n\nСколько штук? (введите число)"

    keyboard = [[InlineKeyboardButton("⬅️ Orqaga / Назад", callback_data=f"back_prod")]]
    await query.edit_message_text(text, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    return ENTERING_QTY

async def back_to_products(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    cat = ctx.user_data.get("current_cat")
    # Simulate category selection
    query.data = f"cat_{cat}"
    return await choose_category(update, ctx)

async def enter_qty(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    lang = ctx.user_data.get("lang", "uz")
    text = update.message.text.strip()

    if not text.isdigit() or int(text) < 1:
        if lang == "uz":
            await update.message.reply_text("❗ Iltimos, to'g'ri raqam kiriting (masalan: 2)")
        else:
            await update.message.reply_text("❗ Пожалуйста, введите правильное число (например: 2)")
        return ENTERING_QTY

    qty = int(text)
    product = ctx.user_data["current_product"]
    cart = ctx.user_data.get("cart", [])

    # Check if already in cart
    existing = next((i for i in cart if i["id"] == product["id"]), None)
    if existing:
        existing["qty"] += qty
    else:
        cart.append({"id": product["id"], "name": product["name"], "price": product["price"], "unit": product["unit"], "qty": qty})
    ctx.user_data["cart"] = cart

    total = sum(i["price"] * i["qty"] for i in cart)
    total_txt = f"{total:,} so'm".replace(",", " ")

    if lang == "uz":
        msg = f"✅ *{product['name']}* — {qty} ta savatga qo'shildi!\n\n🛒 Jami: {total_txt}"
    else:
        msg = f"✅ *{product['name']}* — {qty} шт. добавлено в корзину!\n\n🛒 Итого: {total_txt}"

    keyboard = [
        [InlineKeyboardButton("🛍️ Davom etish / Продолжить", callback_data="continue_shopping")],
        [InlineKeyboardButton("✅ Zakaz berish / Оформить", callback_data="checkout")],
    ]
    await update.message.reply_text(msg, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    return CHOOSING_CATEGORY

async def continue_or_checkout(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "checkout":
        return await ask_name(query, ctx)
    else:
        return await show_categories(query, ctx)

async def ask_name(query, ctx):
    lang = ctx.user_data.get("lang", "uz")
    if lang == "uz":
        text = "👤 Ismingizni yozing:"
    else:
        text = "👤 Напишите ваше имя:"

    await query.edit_message_text(text, parse_mode="Markdown")
    return ENTERING_NAME

async def enter_name(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["customer_name"] = update.message.text.strip()
    lang = ctx.user_data.get("lang", "uz")

    if lang == "uz":
        await update.message.reply_text("📞 Telefon raqamingizni yozing:\n(masalan: +998901234567)")
    else:
        await update.message.reply_text("📞 Напишите ваш номер телефона:\n(например: +998901234567)")
    return ENTERING_PHONE

async def enter_phone(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    ctx.user_data["customer_phone"] = update.message.text.strip()
    lang = ctx.user_data.get("lang", "uz")
    cart = ctx.user_data.get("cart", [])
    name = ctx.user_data.get("customer_name")
    phone = ctx.user_data.get("customer_phone")

    # Build order summary
    lines = []
    total = 0
    for item in cart:
        subtotal = item["price"] * item["qty"]
        total += subtotal
        price_txt = f"{subtotal:,} so'm".replace(",", " ")
        lines.append(f"• {item['name']} × {item['qty']} = {price_txt}")

    total_txt = f"{total:,} so'm".replace(",", " ")
    order_text = "\n".join(lines)

    if lang == "uz":
        summary = (
            f"📋 *Zakaz tasdig'i:*\n\n"
            f"👤 Ism: {name}\n"
            f"📞 Tel: {phone}\n\n"
            f"🛒 *Mahsulotlar:*\n{order_text}\n\n"
            f"💰 *Jami: {total_txt}*"
        )
        keyboard = [
            [InlineKeyboardButton("✅ Tasdiqlash", callback_data="confirm_order")],
            [InlineKeyboardButton("❌ Bekor qilish", callback_data="cancel_order")],
        ]
    else:
        summary = (
            f"📋 *Подтверждение заказа:*\n\n"
            f"👤 Имя: {name}\n"
            f"📞 Тел: {phone}\n\n"
            f"🛒 *Товары:*\n{order_text}\n\n"
            f"💰 *Итого: {total_txt}*"
        )
        keyboard = [
            [InlineKeyboardButton("✅ Подтвердить", callback_data="confirm_order")],
            [InlineKeyboardButton("❌ Отменить", callback_data="cancel_order")],
        ]

    await update.message.reply_text(summary, parse_mode="Markdown", reply_markup=InlineKeyboardMarkup(keyboard))
    return CONFIRMING

async def confirm_order(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == "cancel_order":
        ctx.user_data["cart"] = []
        lang = ctx.user_data.get("lang", "uz")
        if lang == "uz":
            await query.edit_message_text("❌ Zakaz bekor qilindi. /start — qaytadan boshlash")
        else:
            await query.edit_message_text("❌ Заказ отменён. /start — начать заново")
        return ConversationHandler.END

    cart = ctx.user_data.get("cart", [])
    name = ctx.user_data.get("customer_name")
    phone = ctx.user_data.get("customer_phone")
    lang = ctx.user_data.get("lang", "uz")
    user = query.from_user

    lines = []
    total = 0
    for item in cart:
        subtotal = item["price"] * item["qty"]
        total += subtotal
        price_txt = f"{subtotal:,} so'm".replace(",", " ")
        lines.append(f"• {item['name']} × {item['qty']} = {price_txt}")

    total_txt = f"{total:,} so'm".replace(",", " ")
    order_text = "\n".join(lines)
    tg_user = f"@{user.username}" if user.username else f"ID: {user.id}"

    group_msg = (
        f"🛒 *YANGI ZAKAZ!*\n\n"
        f"👤 Mijoz: {name}\n"
        f"📞 Tel: {phone}\n"
        f"💬 Telegram: {tg_user}\n\n"
        f"📦 *Mahsulotlar:*\n{order_text}\n\n"
        f"💰 *JAMI: {total_txt}*\n\n"
        f"🕐 Vaqt: {__import__('datetime').datetime.now().strftime('%d.%m.%Y %H:%M')}"
    )

    try:
        await ctx.bot.send_message(chat_id=OWNER_ID, text=group_msg, parse_mode="Markdown")
        if lang == "uz":
            await query.edit_message_text(
                "🎉 *Zakaz qabul qilindi!*\n\n"
                "Tez orada siz bilan bog'lanamiz.\n"
                "📞 Savollar uchun: @universalshop2026\n\n"
                "Rahmat! 🙏",
                parse_mode="Markdown"
            )
        else:
            await query.edit_message_text(
                "🎉 *Заказ принят!*\n\n"
                "Мы свяжемся с вами в ближайшее время.\n"
                "📞 Вопросы: @universalshop2026\n\n"
                "Спасибо! 🙏",
                parse_mode="Markdown"
            )
    except Exception as e:
        await query.edit_message_text(f"❗ Xatolik yuz berdi: {e}")

    ctx.user_data.clear()
    return ConversationHandler.END

async def cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("❌ Bekor qilindi. /start — qaytadan boshlash")
    return ConversationHandler.END

def main():
    app = Application.builder().token(BOT_TOKEN).build()

    conv_handler = ConversationHandler(
        entry_points=[CommandHandler("start", start)],
        states={
            CHOOSING_LANG: [CallbackQueryHandler(choose_lang, pattern="^lang_")],
            CHOOSING_CATEGORY: [
                CallbackQueryHandler(choose_category, pattern="^cat_"),
                CallbackQueryHandler(continue_or_checkout, pattern="^(checkout|continue_shopping)$"),
            ],
            CHOOSING_PRODUCT: [
                CallbackQueryHandler(choose_product, pattern="^(prod_|back_cat)"),
            ],
            ENTERING_QTY: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, enter_qty),
                CallbackQueryHandler(back_to_products, pattern="^back_prod$"),
            ],
            ENTERING_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_name)],
            ENTERING_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, enter_phone)],
            CONFIRMING: [CallbackQueryHandler(confirm_order, pattern="^(confirm_order|cancel_order)$")],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
        allow_reentry=True,
    )

    app.add_handler(conv_handler)
    print("✅ Universal Shop Bot ishga tushdi!")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()
